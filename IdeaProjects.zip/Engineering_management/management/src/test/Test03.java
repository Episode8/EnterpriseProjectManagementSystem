package test;

import domain.Worker;
import utils.BeanHandler;
import utils.BeanListHandler;
import utils.CRUDUtil;

import java.util.List;

public class Test03 {
    public static void main(String[] args) {

        String sql="select * from worker where number = 12456489984";
        List<Worker> workers = CRUDUtil.executeQuery(sql, new BeanListHandler<>(Worker.class));

        System.out.println(workers.size());
    }
}

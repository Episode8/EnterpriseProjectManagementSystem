package test;

import dao.WorkerDao;
import dao.imp.WorkerDaoImp;
import service.EngineeringGroupService;

public class text01 {
    public static void main(String[] args) {
        WorkerDao wd = new WorkerDaoImp();
        boolean noJob = wd.isNoJob("3121005001", 3);
        System.out.println(noJob);
    }
}

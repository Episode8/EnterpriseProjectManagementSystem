package service;

import domain.Worker;

/**
 * @author LONG
 */
public interface WorkerService {
    public boolean register(Worker worker);
    public boolean upPo(String number,int po);
}

package service;

import domain.EngineeringGroup;

import java.util.List;

public interface EngineeringGroupService {
    public List<EngineeringGroup> findEGroup(String number, int pid);
    public boolean createEG(EngineeringGroup eg,String donumber);
    public boolean updateEG(EngineeringGroup eg,String donumber);
    public boolean updateManager(int eid,String number,String preMan,String donumber);
    public boolean completeET(int eid,String donumber);
    public boolean deleteEG(int eid,String manager_num,String donumber);
}

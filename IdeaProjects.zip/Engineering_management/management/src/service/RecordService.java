package service;

public interface RecordService {
    public boolean taskCompRec(int sid,String number);
}

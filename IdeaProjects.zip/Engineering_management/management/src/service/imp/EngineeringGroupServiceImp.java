package service.imp;

import dao.*;
import dao.imp.*;
import domain.EngineeringGroup;
import domain.SmallGroup;
import service.EngineeringGroupService;
import service.SmallGroupService;

import java.util.List;

public class EngineeringGroupServiceImp implements EngineeringGroupService {


    @Override
    /**查找工程队*/
    public List<EngineeringGroup> findEGroup(String number, int pid) {
        EngineeringGroupDao egd = new EngineeringGroupDaoImp();
        List<EngineeringGroup> engineeringGroups=null;
        switch (pid){
            case 3: engineeringGroups=egd.findGroupId3(number);break;
            case 4: engineeringGroups=egd.findGroupId4();break;
        }
        return engineeringGroups;
    }

    /**创建工程队*/
    @Override
    public boolean createEG(EngineeringGroup eg, String donumber) {
        WorkerDao wd =new WorkerDaoImp();
        EngineeringGroupDao egd = new EngineeringGroupDaoImp();
        EngineeringRecordDao erd =new EngineeringRecordDaoImp();
        /**1.判断施工经理是否正确且空闲*/
        boolean noJob = wd.isNoJob(eg.getManager_num(), 3);
        if(noJob){
            /**2.创建工程队*/
            boolean eg1 = egd.createEG(eg);
            if(eg1){
                /**3.修改施工经理状态*/
                boolean b = wd.givingJob(eg.getManager_num(), 1);
                if(b){
                    /**4.记录*/
                    boolean b1 = erd.engineeringRecord(eg.getId(), donumber + "创建工程队");
                    if(b1){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**修改工程信息*/
    @Override
    public boolean updateEG(EngineeringGroup eg, String donumber) {
        EngineeringGroupDao egd = new EngineeringGroupDaoImp();
        EngineeringRecordDao erd = new EngineeringRecordDaoImp();
        /**1.修改信息*/
        boolean b = egd.updateEG(eg);
        if(b){
            /**2.记录*/
            boolean b1 = erd.engineeringRecord(eg.getId(), donumber + "修改信息");
            if(b1){
                return true;
            }
        }
        return false;
    }

    /**换施工经理*/
    @Override
    public boolean updateManager(int eid, String number, String preMan,String donumber) {
        WorkerDao wd = new WorkerDaoImp();
        EngineeringRecordDao erd = new EngineeringRecordDaoImp();
        EngineeringGroupDao egd = new EngineeringGroupDaoImp();
        /**判断交换的是否符合*/
        boolean noJob = wd.isNoJob(number, 3);
        if(noJob){
            /**修改*/
            boolean b = egd.updateManager(eid, number);
            if(b){
                /**原施工经理空闲，现施工忙碌*/
                boolean b1 = wd.givingJob(number, 1);
                boolean b2 = wd.givingJob(preMan, 0);
                if(b1&&b2){
                    /**记录*/
                    boolean b3 = erd.engineeringRecord(eid, donumber + "交换经理" + preMan + "to" + number);
                    if(b3){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**完成任务*/
    @Override
    public boolean completeET(int eid, String donumber) {
        /**1.判断工程队下小组是否完成任务*/
        SmallGroupDao sgd = new SmallGroupDaoImp();
        List<SmallGroup> groupOfE = sgd.findGroupOfE(eid);
        if(groupOfE!=null&&groupOfE.size()!=0){
            for(SmallGroup sg :groupOfE){
                if(sg.getSg_completion()!=1){
                    return false;
                }
            }
            /**2.完成工程任务*/
            EngineeringGroupDao egd = new EngineeringGroupDaoImp();
            boolean b = egd.completeET(eid);
            if(b){
                /**3.记录*/
                EngineeringRecordDao erd = new EngineeringRecordDaoImp();
                boolean b1 = erd.engineeringRecord(eid, donumber + "提交工程任务");
                if(b1){
                    return true;
                }else {
                    return false;
                }
            }
        }
        return false;
    }

    /**删除工程队*/
    @Override
    public boolean deleteEG(int eid, String manager_num,String donumber) {
        /**1.找到工程队的每一个小组进行删除*/
        SmallGroupService sgs =new SmallGroupServiceImp();
        SmallGroupDao sgd = new SmallGroupDaoImp();
        List<SmallGroup> groupOfE = sgd.findGroupOfE(eid);
        if(groupOfE!=null){
            for(SmallGroup sg :groupOfE){
                boolean b = sgs.deG(sg.getId(), sg.getContractor_num(), donumber);
                if(!b){
                    return false;
                }
            }
        }
        /**2.删除记录*/
        EngineeringRecordDao erd = new EngineeringRecordDaoImp();
        boolean b2 = erd.deAER(eid);
        if(b2){
            /**3.删除工程队*/
            EngineeringGroupDao egd = new EngineeringGroupDaoImp();
            boolean b = egd.deleteEG(eid);
            if(b){
                /**4.删除经理工作*/
                WorkerDao wd = new WorkerDaoImp();
                boolean b1 = wd.givingJob(manager_num, 0);
                if(b1){
                    /**5.记录删除*/
                    DeRecordDao ded = new DeRecordDaoImp();
                    boolean b3 = ded.deRecord(donumber + "删除工程队" + eid);
                    if(b3){
                        return true;
                    }
                }
            }
        }
        return false;
    }

}

package service.imp;

import dao.*;
import dao.imp.*;
import domain.DeRecord;
import domain.SmallGroup;
import domain.Worker;
import service.SmallGroupService;

import java.util.List;

public class SmallGroupServiceImp implements SmallGroupService {
    @Override
    public List<SmallGroup> findGroup(String number, int pid) {
        List<SmallGroup> smallGroups =null;

        SmallGroupDao smallGroupDao = new SmallGroupDaoImp();
        switch (pid){
            case 1: smallGroups = smallGroupDao.findGroup1(number);break;
            case 2: smallGroups = smallGroupDao.findGroup2(number);break;
            case 3: smallGroups = smallGroupDao.findGroup3(number);break;
            case 4: smallGroups = smallGroupDao.findFGroup4();break;
        }
        return smallGroups;

    }

    /**创建小组*/
    @Override
    public boolean createSG(SmallGroup s,String number) {
        WorkerDao wd = new WorkerDaoImp();
        /**判断包工头是否可用，修改工作状态，创建小组，增加记录*/
        boolean contractor = wd.isNoJob(s.getContractor_num(),2);
        if(contractor){
            SmallGroupDao sgd=new SmallGroupDaoImp();
            /**创建小组*/
            boolean g = sgd.createG(s);
            if(g){
                /**包工头分配任务（不空闲）*/
                boolean b = wd.givingJob(s.getContractor_num(), 1);
                if(b){
                    /**小组记录*/
                    SmallRecordDao srd = new SmallRecordDaoImp();
                    boolean b1 = srd.smallRecord(s.getId(), number + "创建小组");
                    if(b1){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**修改小组数据存储记录*/
    @Override
    public boolean updateSGInfo(SmallGroup s, String number) {
        SmallGroupDao sgd = new SmallGroupDaoImp();
        boolean b = sgd.upI(s);
        if(b){
            SmallRecordDao srd = new SmallRecordDaoImp();
            boolean b1 = srd.smallRecord(s.getId(), number + "修改小组信息");
            if(b1){
                return true;
            }
        }
        return false;
    }

    /**换包工头*/
    @Override
    /**修改后的数据，和修改前的包工头，修改人*/
    public boolean upCont(SmallGroup s, String donumber,String preCont) {
        SmallGroupDao sgd = new SmallGroupDaoImp();
        WorkerDao wd = new WorkerDaoImp();
        SmallRecordDao srd = new SmallRecordDaoImp();
        /**判断是否是包工头且无任务*/
        boolean b2 = wd.isNoJob(s.getContractor_num(),2);
        if(b2){
            /**修改*/
            boolean b = sgd.upCon(s);
            if(b){
                /**原理包工头去任务，现任包工头加任务*/
                boolean b4 = wd.givingJob(s.getContractor_num(), 1);
                boolean b3 = wd.givingJob(preCont, 0);
                if(b3&&b4){
                    /**小组记录*/
                    boolean b1 = srd.smallRecord(s.getId(), donumber + "换包工头"+preCont+"to"+s.getContractor_num());
                    if(b1){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**添加员工操作*/
    @Override
    public boolean upW(String number, String task, int gid,String donumber) {
        WorkerDao wd = new WorkerDaoImp();
        SmallRecordDao wrd = new SmallRecordDaoImp();
        TaskDao td = new TaskDaoImp();
        /**判断小工是否可以添加*/
        boolean noJob = wd.isNoJob(number, 1);
        if(noJob){
            /**添加员工*/
            boolean b = td.upTask(number, task, gid);
            if(b){
                /**设置员工有工作*/
                boolean b2 = wd.givingJob(number, 1);
                if(b2){
                    /**小组记录*/
                    boolean b1 = wrd.smallRecord(gid, donumber + "添加员工" + number);
                    if(b1){
                        return true;
                    }
                }

            }
        }
        return false;
    }

    /**删除小组员工*/
    @Override
    public boolean deW(String number, int gid, String donumber) {
        SmallRecordDao srd = new SmallRecordDaoImp();
        TaskDao td = new TaskDaoImp();
        WorkerDao wd = new WorkerDaoImp();
        /**删除员工任务*/
        boolean b = td.deTask(number);
        if(b){
            /**设置员工空闲*/
            boolean b1 = wd.givingJob(number, 0);
            if(b1){
                /**小组记录*/
                boolean b2 = srd.smallRecord(gid, donumber + "删除员工" + number);
                if(b2){
                    return true;
                }
            }
        }
        return false;
    }

    /**删除小组*/
    @Override
    public boolean deG(int gid,String cont, String donumber) {
        SmallGroupDao sgd = new SmallGroupDaoImp();
        TaskDao td = new TaskDaoImp();
        WorkerDao wd = new WorkerDaoImp();
        SmallRecordDao srd = new SmallRecordDaoImp();
        /**1.删除小组员工*/
        List<Worker> gWoker = sgd.findGWoker(gid);
        if (gWoker != null && gWoker.size() != 0) {
            for (Worker w : gWoker) {
                /**1.1删除员工工作状态和任务信息*/
                wd.givingJob(w.getNumber(), 0);
                td.deTask(w.getNumber());
            }
        }
        /**1.2删除包工头工作状态*/
        wd.givingJob(cont, 0);
        /**2.删除记录*/
        boolean b1 = srd.deASR(gid);
        if (b1) {
            /**3.删除小组信息*/
            boolean b = sgd.deG(gid);
            if(b){
                DeRecordDao ded = new DeRecordDaoImp();
                boolean b2 = ded.deRecord(donumber + "删除小组" + gid);
                if(b2){
                    return true;
                }
            }
        }
        return false;
    }

    /**完成小组任务*/
    @Override
    public boolean completeT(int gid, String donumber) {
        /**判断小组成员任务是否都完成*/
        SmallGroupDao sgd = new SmallGroupDaoImp();
        List<Worker> gWoker = sgd.findGWoker(gid);
        if(gWoker!=null&&gWoker.size()!=0){
            for(Worker w :gWoker){
                if(w.getTask_completion()==0){
                    return false;
                }
            }
            /**完成*/
            boolean b = sgd.completeT(gid);
            if(b){
                /**记录*/
                SmallRecordDao srd= new SmallRecordDaoImp();
                boolean b1 = srd.smallRecord(gid, donumber + "提交完成了小组任务");
                if(b1){
                    return true;
                }
            }
        }
        return false;
    }

}

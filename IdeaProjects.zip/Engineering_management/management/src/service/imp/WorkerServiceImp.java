package service.imp;

import dao.WorkerDao;
import dao.imp.WorkerDaoImp;
import domain.Worker;
import service.WorkerService;

import java.nio.file.WatchService;

/**
 * @author LONG
 */
public class WorkerServiceImp implements WorkerService {
    @Override
    public boolean register(Worker worker) {
        WorkerDao workerDao = new WorkerDaoImp();
        //1.判断职工号是否存在
        boolean e = workerDao.findNumber(worker.getNumber());
        //如果存在，则返回注册失败
        if(e){
            return false;
        }else{
            //如果不存在则存储信息
            boolean b = workerDao.saveWokerInfo(worker);
            if (b){
                //存储成功返回true
                return true;
            }else {
                //存储失败返回false
                return false;
            }
        }
    }

    /**修改用户职位*/
    @Override
    public boolean upPo(String number,int po) {
        /**先判断用户是否无工作*/
        WorkerDao wd =new WorkerDaoImp();
        boolean noJob = wd.isNoJob(number);
        if(noJob){
            /**改变职位*/
            boolean b = wd.upPo(number, po);
            if(b){
                return true;
            }
        }
        return false;
    }


}

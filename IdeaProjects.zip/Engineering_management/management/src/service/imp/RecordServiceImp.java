package service.imp;


import dao.SmallRecordDao;
import dao.TaskDao;

import dao.imp.SmallRecordDaoImp;
import dao.imp.TaskDaoImp;
import service.RecordService;

public class RecordServiceImp implements RecordService {
    @Override
    /**传入小组号和员工编号来记录*/
    public boolean taskCompRec(int sid, String number) {
        TaskDao taskDao =new TaskDaoImp();
        SmallRecordDao recordDao =new SmallRecordDaoImp();
        boolean b = taskDao.taskComplete(number);
        if(b){
            /**成功完成后写操作记录*/
            String record="员工"+number+"完成了任务";
            boolean b1 = recordDao.smallRecord(sid, record);
            if (b1){
                /**操作记录成功后返回true*/
                return true;
            }else {
                return false;
            }
        }else {
            return false;
        }

    }
}

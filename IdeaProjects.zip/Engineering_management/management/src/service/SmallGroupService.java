package service;

import domain.SmallGroup;

import java.util.List;

/**
 * @author LONG
 */
public interface SmallGroupService {
    public <SmallGroup> List<SmallGroup> findGroup(String number,int pid);

    public boolean createSG(SmallGroup s,String number);
    public boolean updateSGInfo(SmallGroup s,String number);
    public boolean upCont(SmallGroup s,String donumber,String preCont);
    public boolean upW(String number,String task,int gid,String donumber);
    public boolean deW(String number,int gid,String donumber);
    public boolean deG(int gid,String cont,String donumber);
    public boolean completeT(int gid,String donumber);
}

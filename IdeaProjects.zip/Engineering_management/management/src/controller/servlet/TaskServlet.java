package controller.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import dao.TaskDao;
import dao.WorkerDao;
import dao.imp.TaskDaoImp;
import dao.imp.WorkerDaoImp;
import domain.ResultInfo;
import domain.SmallGroup;
import domain.Worker;
import domain.WorkerTask;
import javafx.concurrent.Task;
import service.RecordService;
import service.SmallGroupService;
import service.imp.RecordServiceImp;
import service.imp.SmallGroupServiceImp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/TaskServlet")
public class TaskServlet extends BaseServlet{

    /**获取小工工作任务*/
    public void myTask(HttpServletRequest request,HttpServletResponse response) throws IOException {
        //获得用户number
        HttpSession session = request.getSession();
        Worker worker1 = (Worker) session.getAttribute("worker");
        String value = worker1.getNumber();
        //调用方法找到task
        TaskDao taskDao = new TaskDaoImp();
        WorkerTask task = taskDao.findTask(value);
        //回显信息
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        /**成功找到返回对象*/
        if(task!=null){
            //增加task数据存储再session中
            session.setAttribute("task",task);
            resultInfo.setSuccess(true);
            resultInfo.setMessage("查找成功");
            resultInfo.setData(task);
            om.writeValue(response.getWriter(),resultInfo);
        }else{/**没有数据返回相应信息*/
            resultInfo.setSuccess(false);
            resultInfo.setMessage("没有数据");
            om.writeValue(response.getWriter(),resultInfo);
        }
    }
    /**完成任务*/  /**还缺少记录*/
    public void taskCp(HttpServletRequest request,HttpServletResponse response) throws IOException {
        /**获取session中小组号和员工职工号*/
        HttpSession session = request.getSession();
        Worker worker1 = (Worker) session.getAttribute("worker");
        WorkerTask task = (WorkerTask) session.getAttribute("task");
        RecordService recordService = new RecordServiceImp();
        /**调用方法完成并记录*/
        boolean b =  recordService.taskCompRec(task.getGroup_id(), worker1.getNumber());

        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om =new ObjectMapper();
        //根据返回值来封装返回信息
        if(b){
            resultInfo.setSuccess(true);
            resultInfo.setMessage("提交成功");
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("提交失败");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }

    /**获取所有任务*/
    public void AllTask(HttpServletRequest request,HttpServletResponse response) throws IOException {
        TaskDao td = new TaskDaoImp();
        List<WorkerTask> tasks = td.allTask();
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om =new ObjectMapper();
        if(tasks!=null&&tasks.size()!=0){
            resultInfo.setSuccess(true);
            resultInfo.setData(tasks);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("无任何任务");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }
}

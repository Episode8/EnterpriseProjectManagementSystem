package controller.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import dao.DeRecordDao;
import dao.WorkerDao;
import dao.imp.DeRecordDaoImp;
import dao.imp.WorkerDaoImp;
import domain.DeRecord;
import domain.ResultInfo;
import domain.Worker;
import service.WorkerService;
import service.imp.WorkerServiceImp;
import domain.WorkerUtil;

import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/UserServlet")
public class UserServlet extends BaseServlet {

    public void register(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Worker worker = new Worker();

        //封装worker对象
        worker.setNumber(request.getParameter("number"));
        worker.setPassword(request.getParameter("password"));
        worker.setName(request.getParameter("name"));
        worker.setGender(Integer.parseInt(request.getParameter("gender")));
        worker.setHiredate(Date.valueOf(request.getParameter("hiredate")));
        worker.setPosition_id(Integer.parseInt(request.getParameter("position")));

        worker.setPhone_number(request.getParameter("phone_number"));
        //调用注册方法
        WorkerService workerService = new WorkerServiceImp();
        boolean register = workerService.register(worker);
        //设置响应体参数
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        //根据注册成功与否返回json数据
        if (register) {
            resultInfo.setSuccess(true);
            resultInfo.setMessage("注册成功");
            om.writeValue(response.getWriter(), resultInfo);
        } else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("注册失败，职工号已经存在");
            om.writeValue(response.getWriter(), resultInfo);
        }
    }



    /**登录*/
   public void login(HttpServletRequest request,HttpServletResponse response) throws IOException {

       //调用类方法将参数封装成worker
       Worker worker = WorkerUtil.requestToWorker(request);
       //调用登录方法。
       WorkerDao wd = new WorkerDaoImp();
       Worker worker1 = wd.workerLogin(worker);
       ResultInfo resultInfo = new ResultInfo();
       ObjectMapper om = new ObjectMapper();
       response.setContentType("application/json;charset=utf-8");
       //判断返回值
       if(worker1!=null){
           //不为null，新增session存储用户信息
           HttpSession session = request.getSession();
           session.setAttribute("worker",worker1);

           //设置返回json数据
           resultInfo.setSuccess(true);
           resultInfo.setMessage("登录成功");
           //返回数据
           om.writeValue(response.getWriter(),resultInfo);
       }else{
           //登录失败返回相应失败信息
           resultInfo.setSuccess(false);
           resultInfo.setMessage("职工号或密码错误");
           om.writeValue(response.getWriter(),resultInfo);
       }
   }

   /**返回员工信息的功能*/
    public void loadInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
       //根据Session数据获取用户名
        HttpSession session = request.getSession();
        Worker worker1 = (Worker) session.getAttribute("worker");
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
       /**判断是否登录*/
       if(worker1!=null){
           String value = worker1.getNumber();
           //调用方法执行功能
           WorkerDao workerDao = new WorkerDaoImp();
           Worker worker = workerDao.loadW(value);
           /**设置信息*/
           if(worker!=null){
               resultInfo.setSuccess(true);
               resultInfo.setData(worker);
               om.writeValue(response.getWriter(),resultInfo);
           }else {
               resultInfo.setSuccess(false);
               resultInfo.setMessage("请登录");
               om.writeValue(response.getWriter(),resultInfo);
           }
       }else {
           resultInfo.setSuccess(false);
           resultInfo.setMessage("请登录");
           om.writeValue(response.getWriter(),resultInfo);
       }

    }

    /**查询所有员工*/
    public void findAllWorker(HttpServletRequest request,HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        /**根据登录是否来查看*/
        if(session.getAttribute("worker")!=null){
            WorkerDao wd = new WorkerDaoImp();
            List<Worker> workers = wd.findAW();
            /**回显信息*/
            if(workers!=null&&workers.size()!=0){
                resultInfo.setSuccess(true);
                resultInfo.setData(workers);
            }else {
                resultInfo.setSuccess(false);
                resultInfo.setMessage("没有员工");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("请登录");
            om.writeValue(response.getWriter(),resultInfo);
        }
    }

    /**搜索员工*/
    public void searchWorker(HttpServletRequest request,HttpServletResponse response) throws IOException {
       /**获取搜索信息字符串*/
        String sinfo = request.getParameter("sinfo");
        HttpSession session = request.getSession();
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        /**根据登录是否来查看*/
        if(session.getAttribute("worker")!=null){
            WorkerDao wd = new WorkerDaoImp();
            List<Worker> workers = wd.searchW(sinfo);
            if(workers!=null&&workers.size()!=0){
                resultInfo.setSuccess(true);
                resultInfo.setData(workers);
            }else{
                resultInfo.setSuccess(false);
                resultInfo.setMessage("没有员工");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else{
            resultInfo.setSuccess(false);
            resultInfo.setMessage("请登录");
            om.writeValue(response.getWriter(),resultInfo);
        }
    }

    /**修改个人信息*/
    public void updateInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
        Worker worker =new Worker();
        worker.setNumber(request.getParameter("number"));
        worker.setName(request.getParameter("name"));
        worker.setGender(Integer.valueOf(request.getParameter("gender")));
        worker.setHiredate(Date.valueOf(request.getParameter("hiredate")));
        worker.setPhone_number(request.getParameter("phone_number"));
        worker.setPassword(request.getParameter("password"));
        WorkerDao wd =new WorkerDaoImp();
        boolean b = wd.updateInfo(worker);
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        if(b){
            resultInfo.setSuccess(true);
            resultInfo.setMessage("修改成功");
        }else{
            resultInfo.setSuccess(false);
            resultInfo.setMessage("修改失败");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }


    public void changePosition(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String number = request.getParameter("number");
        String position_id = request.getParameter("position_id");
        WorkerDao wd = new WorkerDaoImp();
        /**调用方法*/
        boolean b = wd.upPo(number, Integer.parseInt(position_id));
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        if(b){
            resultInfo.setSuccess(true);
            resultInfo.setMessage("修改成功");
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("修改失败");
        }
        om.writeValue(response.getWriter(),resultInfo);

    }
    /**查看删除记录*/
    public void deRecord(HttpServletRequest request,HttpServletResponse response) throws IOException {
       /**是否是管理员*/
        HttpSession session = request.getSession();
        Worker worker =(Worker) session.getAttribute("worker");
        Integer position_id = worker.getPosition_id();
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        if(position_id==5){
            DeRecordDao drd = new DeRecordDaoImp();
            List<DeRecord> deRecords = drd.AllDeRecord();
            if(deRecords!=null&&deRecords.size()!=0){
                resultInfo.setSuccess(true);
                resultInfo.setData(deRecords);
            }else {
                resultInfo.setSuccess(false);
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            om.writeValue(response.getWriter(),resultInfo);
        }
    }

}

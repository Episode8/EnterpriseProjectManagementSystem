package controller.servlet;


import com.fasterxml.jackson.databind.ObjectMapper;
import dao.EngineeringRecordDao;
import dao.SmallGroupDao;
import dao.imp.EngineeringRecordDaoImp;
import dao.imp.SmallGroupDaoImp;
import domain.*;
import service.EngineeringGroupService;
import service.imp.EngineeringGroupServiceImp;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet("/EngineeringGroupServlet")
public class EngineeringGroupServlet extends BaseServlet{

    /**找到对应的工程队，并且存储到session中*/
    public void findEGroupId(HttpServletRequest request,HttpServletResponse response) throws IOException {
        /**获取员工信息*/
        HttpSession session = request.getSession();
        Worker worker = (Worker) session.getAttribute("worker");
        EngineeringGroupService egs = new EngineeringGroupServiceImp();
        /**根据职位和职工号来找工程队*/
        List<EngineeringGroup> eGroups = egs.findEGroup(worker.getNumber(), worker.getPosition_id());
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(eGroups!=null&&eGroups.size()!=0){
            /**将工程队对象存储再session中 用eid+工程队id*/
            for(int i =0;i<eGroups.size();i++){
                EngineeringGroup engineeringGroup = eGroups.get(i);
                session.setAttribute("eid"+engineeringGroup.getId(),engineeringGroup);
            }
            resultInfo.setSuccess(true);
            resultInfo.setData(eGroups);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("无工程队");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }

    /**找施工队信息*/
    public void findGroupInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String eid = request.getParameter("eid");
        HttpSession session = request.getSession();
        EngineeringGroup engineeringGroup =(EngineeringGroup) session.getAttribute("eid" + eid);
        /**设置回显信息*/
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(engineeringGroup!=null){
            resultInfo.setSuccess(true);
            resultInfo.setData(engineeringGroup);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("无信息");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }

    /**找对应小组*/
    public void findSmallOfEngineering(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String eid = request.getParameter("eid");
        SmallGroupDao sgd = new SmallGroupDaoImp();
        List<SmallGroup> groupOfEs = sgd.findGroupOfE(Integer.parseInt(eid));
        /**设置回显信息*/
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(groupOfEs!=null&&groupOfEs.size()>0){
            resultInfo.setSuccess(true);
            resultInfo.setData(groupOfEs);
        }else {
            resultInfo.setSuccess(false);
        }
        om.writeValue(response.getWriter(),resultInfo);
    }

    /**创建工程队*/
    public void createEGroup(HttpServletRequest request,HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        HttpSession session = request.getSession();
        Worker worker = (Worker) session.getAttribute("worker");
        /**判断是否有权限*/
        if(worker.getPosition_id()==3||worker.getPosition_id()==4){
            EngineeringGroup eg =new EngineeringGroup();
            /**封装创建信息*/
            eg.setId(Integer.parseInt(request.getParameter("id")));
            eg.setGroup_name(request.getParameter("name"));
            eg.setTask_info(request.getParameter("task_info"));
            eg.setTask_dif(request.getParameter("task_dif"));
            eg.setTask_deadline(Date.valueOf(request.getParameter("task_deadline")));
            eg.setManager_num(request.getParameter("manager_num"));
            EngineeringGroupService egs = new EngineeringGroupServiceImp();
            boolean eg1 = egs.createEG(eg, worker.getNumber());
            if(eg1){
                resultInfo.setSuccess(true);
                resultInfo.setMessage("创建成功");
            }else {
                resultInfo.setSuccess(false);
                resultInfo.setMessage("创建失败");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("权限不够");
            om.writeValue(response.getWriter(),resultInfo);
        }

    }

    public void updateEGroupInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        /**判断是否选择工程队*/
        if(request.getParameter("id")!=""){
            /**封装修改信息*/
        EngineeringGroup upeg = new EngineeringGroup();
        upeg.setId(Integer.parseInt(request.getParameter("id")));
        upeg.setGroup_name(request.getParameter("group_name"));
        upeg.setTask_info(request.getParameter("task_info"));
        upeg.setTask_dif(request.getParameter("task_dif"));
        upeg.setTask_deadline(Date.valueOf(request.getParameter("task_deadline")));
        /**获取修改者number*/
        HttpSession session = request.getSession();
        Worker worker =(Worker) session.getAttribute("worker");
        String donumber = worker.getNumber();
            /**调用service方法*/
            EngineeringGroupService egs = new EngineeringGroupServiceImp();
            boolean b = egs.updateEG(upeg, donumber);
            /**设置回显信息*/
            if(b){
                resultInfo.setSuccess(true);
                resultInfo.setMessage("修改成功");
            }else {
                resultInfo.setSuccess(false);
                resultInfo.setMessage("修改失败");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("请选择工程队");
            om.writeValue(response.getWriter(),resultInfo);
        }

    }

    /**换施工经理*/
    public void updateManger(HttpServletRequest request,HttpServletResponse response) throws IOException {
        /**获取操作者number*/
        HttpSession session = request.getSession();
        Worker worker =(Worker) session.getAttribute("worker");
        String donumber = worker.getNumber();
        /**获取修改信息*/
        String eid = request.getParameter("id");
        String manager_num = request.getParameter("manager_num");
        String preman = request.getParameter("preman");
        EngineeringGroupService egs= new EngineeringGroupServiceImp();
        /**设置回显信息*/
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(eid!=""){
            boolean b = egs.updateManager(Integer.parseInt(eid), manager_num, preman, donumber);
            if(b){
                resultInfo.setSuccess(true);
                resultInfo.setMessage("交换成功");
            }else {
                resultInfo.setSuccess(false);
                resultInfo.setMessage("交换失败");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("请选择工程队");
            om.writeValue(response.getWriter(),resultInfo);
        }

    }

    /**找到对应工程队记录*/
    public void findERecord(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String eid = request.getParameter("eid");
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(eid!=""){
            EngineeringRecordDao erd = new EngineeringRecordDaoImp();
            List<EngineeringRecord> er = erd.findER(Integer.parseInt(eid));
            if(er!=null&&er.size()!=0){
                resultInfo.setSuccess(true);
                resultInfo.setData(er);
            }else {
                resultInfo.setSuccess(false);
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else{
            resultInfo.setSuccess(false);
            om.writeValue(response.getWriter(),resultInfo);
        }
    }

    /**删除工程队记录*/
    public void deleteERecord(HttpServletRequest request,HttpServletResponse response) throws IOException{
        String rid = request.getParameter("rid");
        EngineeringRecordDao erd = new EngineeringRecordDaoImp();
        boolean b = erd.deER(Integer.parseInt(rid));
        /**设置回显信息*/
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(b){
            resultInfo.setSuccess(true);
            resultInfo.setMessage("删除成功");
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("删除失败");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }

    /**完成工程队任务*/
    public void completeETask(HttpServletRequest request,HttpServletResponse response) throws IOException {
        String eid = request.getParameter("eid");
        EngineeringGroupService egs = new EngineeringGroupServiceImp();
        HttpSession session = request.getSession();
        Worker worker =(Worker) session.getAttribute("worker");
        String donumber = worker.getNumber();
        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        /**判断是否选择工程队*/
        if(eid!=""){
            boolean b = egs.completeET(Integer.parseInt(eid), donumber);
            if(b){
                resultInfo.setSuccess(true);
                resultInfo.setMessage("提交成功");
            }else {
                resultInfo.setSuccess(false);
                resultInfo.setMessage("提交失败");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("请选择工程队");
            om.writeValue(response.getWriter(),resultInfo);
        }
    }

    /**删除工程队*/
    public void deleteEG(HttpServletRequest request,HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        Worker worker =(Worker) session.getAttribute("worker");
        String donumber = worker.getNumber();

        String eid = request.getParameter("eid");
        String manager_num=request.getParameter("manager_num");
        EngineeringGroupService egs = new EngineeringGroupServiceImp();

        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(eid!=""){
            boolean b = egs.deleteEG(Integer.parseInt(eid), manager_num, donumber);
            if(b){
                resultInfo.setSuccess(true);
                resultInfo.setMessage("删除成功");
            }else{
                resultInfo.setSuccess(false);
                resultInfo.setMessage("删除失败");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("请选择工程队");
            om.writeValue(response.getWriter(),resultInfo);
        }

    }

}

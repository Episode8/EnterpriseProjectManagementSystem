package controller.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import dao.SmallGroupDao;
import dao.SmallRecordDao;
import dao.imp.SmallGroupDaoImp;
import dao.imp.SmallRecordDaoImp;
import domain.ResultInfo;
import domain.SmallGroup;
import domain.SmallRecord;
import domain.Worker;
import service.SmallGroupService;
import service.imp.SmallGroupServiceImp;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;


/**
 * @author LONG
 */
@WebServlet("/SmallGroupServlet")
public class SmallGroupServlet extends BaseServlet{


   /**不同职位找小组id并且存储小组信息再session中 session键是gid+小组id*/
    public void findGroupId(HttpServletRequest request, HttpServletResponse response) throws IOException {
        SmallGroupService smallGroupService = new SmallGroupServiceImp();
        /**获取员工信息*/
        HttpSession session = request.getSession();
        Worker worker = (Worker) session.getAttribute("worker");
        List<SmallGroup> group =null;

        /**调用方法*/
        group = smallGroupService.findGroup(worker.getNumber(), worker.getPosition_id());

        response.setContentType("application/json;charset=utf-8");
        ResultInfo resultInfo = new ResultInfo();
        ObjectMapper om = new ObjectMapper();
        if(group.size()!=0){
            for(int i =0;i<group.size();i++){
                SmallGroup smallGroup = group.get(i);
                session.setAttribute("gid"+smallGroup.getId(),smallGroup);
            }
            resultInfo.setSuccess(true);
            resultInfo.setData(group);
        }else {
            resultInfo.setSuccess(false);
            resultInfo.setMessage("没有小组");
        }
        om.writeValue(response.getWriter(),resultInfo);
    }

        /**找小组信息*/
        public void findGroupInfo(HttpServletRequest request, HttpServletResponse response) throws IOException{
            /**获得要查询的小组号*/
            String gid = request.getParameter("gid");
            HttpSession session = request.getSession();
            /**从存储的session数据中获取*/
            SmallGroup smallGroup = (SmallGroup) session.getAttribute("gid" + gid);
            response.setContentType("application/json;charset=utf-8");
            ResultInfo resultInfo = new ResultInfo();
            ObjectMapper om = new ObjectMapper();
            if(smallGroup!=null){
                resultInfo.setSuccess(true);
                resultInfo.setData(smallGroup);
            }else {
                resultInfo.setSuccess(false);
                resultInfo.setMessage("没有信息");
            }
            om.writeValue(response.getWriter(),resultInfo);
        }

        /**找小组员工*/
      public void findGroupWorker(HttpServletRequest request,HttpServletResponse response) throws IOException {
          String gid = request.getParameter("gid");
          SmallGroupDao sgd = new SmallGroupDaoImp();
          List<Worker> wokers = sgd.findGWoker(Integer.parseInt(gid));
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          if(wokers.size()>0){
              resultInfo.setSuccess(true);
              resultInfo.setData(wokers);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("无人");
          }
          om.writeValue(response.getWriter(),resultInfo);
      }

      /**创建新的小组*/
      public void createGroup(HttpServletRequest request,HttpServletResponse response) throws IOException {
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          /**判断是否有权限*/
          if(worker!=null&&worker.getPosition_id()!=1){
              SmallGroup smallGroup = new SmallGroup();
              smallGroup.setId(Integer.parseInt(request.getParameter("id")));
              smallGroup.setGroup_name(request.getParameter("name"));
              smallGroup.setTask_info(request.getParameter("task_info"));
              smallGroup.setTask_dif(request.getParameter("task_dif"));
              smallGroup.setTask_deadline(Date.valueOf(request.getParameter("task_deadline")));
              smallGroup.setContractor_num(request.getParameter("contractor_num"));
              smallGroup.setEngineering_id(Integer.parseInt((request.getParameter("engineering_id"))));
              //调用创建小组方法
              SmallGroupService sgs = new SmallGroupServiceImp();
              boolean sg = sgs.createSG(smallGroup,worker.getNumber());
              //设置回显信息
              if(sg){
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("创建成功");
              }else{
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("创建失败,检查创建信息");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("无权限");
              om.writeValue(response.getWriter(),resultInfo);
          }
      }


      /**修改信息*/
      public void updateInfo(HttpServletRequest request,HttpServletResponse response) throws IOException {
            SmallGroup upsg = new SmallGroup();
            upsg.setId(Integer.parseInt(request.getParameter("id")));
            upsg.setGroup_name(request.getParameter("group_name"));
            upsg.setTask_info(request.getParameter("task_info"));
            upsg.setTask_dif(request.getParameter("task_dif"));
            upsg.setTask_deadline(Date.valueOf(request.getParameter("task_deadline")));
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          SmallGroupService sgs = new SmallGroupServiceImp();
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          if(request.getParameter("id")!=""){
              boolean b = sgs.updateSGInfo(upsg, worker.getNumber());
              if(b){
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("修改成功");
              }else {
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("修改失败");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("请选择小组");
              om.writeValue(response.getWriter(),resultInfo);
          }

      }

      /**更新包工头*/
      public void upContractor(HttpServletRequest request,HttpServletResponse response) throws IOException {
            SmallGroup sg = new SmallGroup();
            sg.setId(Integer.parseInt(request.getParameter("id")));
            sg.setContractor_num(request.getParameter("contractor_num"));
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          SmallGroupService sgs = new SmallGroupServiceImp();
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          /**判断是否选择小组*/
          if(request.getParameter("id")!=""){
              boolean b = sgs.upCont(sg, worker.getNumber(),request.getParameter("cont"));
              if(b){
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("修改成功");
              }else{
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("修改失败");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("请选择小组");
              om.writeValue(response.getWriter(),resultInfo);
          }

      }

      /**添加小工*/
      public void upWorker(HttpServletRequest request,HttpServletResponse response) throws IOException {
          String number = request.getParameter("number");
          String task = request.getParameter("task");
          String gid = request.getParameter("gid");
          /**获取操作者信息*/
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          String donumber = worker.getNumber();
          SmallGroupService sgs = new SmallGroupServiceImp();
          /**设置回显信息*/
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          /**判断是否有小组id*/
          if(gid!=""){
              boolean b = sgs.upW(number, task, Integer.parseInt(gid), donumber);

              if(b){
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("操作成功");
              }else {
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("操作失败");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("请选择小组");
              om.writeValue(response.getWriter(),resultInfo);
          }

      }

      /**删除员工*/
      public void deWorker(HttpServletRequest request,HttpServletResponse response) throws IOException {
          /**获取删除信息*/
          String denumber = request.getParameter("denumber");
          String gid = request.getParameter("gid");
          /**获取操作者信息*/
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          Integer position_id = worker.getPosition_id();
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          if(position_id!=1){
              String donumber = worker.getNumber();
              /**调用方法*/
              SmallGroupService sgs =new SmallGroupServiceImp();
              boolean b = sgs.deW(denumber, Integer.parseInt(gid), donumber);

              if (b) {
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("操作成功");
              }else {
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("操作失败");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("权限不够");
          }


      }

      /**删除小组*/
      public void deGroup(HttpServletRequest request,HttpServletResponse response) throws IOException {
          /**获取操作者信息和要删除的gid*/
          String gid = request.getParameter("gid");
          String cont = request.getParameter("cont");
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          String donumber = worker.getNumber();
          SmallGroupService sgs = new SmallGroupServiceImp();
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          /**判断是否选择小组*/
          if(gid!=""){
              /**调用方法*/
              boolean b = sgs.deG(Integer.parseInt(gid), cont, donumber);
              /**设置回显信息*/
              if(b){
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("删除成功");
              }else {
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("删除失败");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("请选择小组");
              om.writeValue(response.getWriter(),resultInfo);
          }

      }

      /**小组记录显示*/
      public void smallRecord(HttpServletRequest request,HttpServletResponse response) throws IOException {
          /**根据小组id获取小组记录*/
          String sid = request.getParameter("gid");
          SmallRecordDao srd = new SmallRecordDaoImp();
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
         /**判断是否选择小组*/
          if(sid!=""){
              List<SmallRecord> smallRecords = srd.findSmallRecord(Integer.parseInt(sid));
              if(smallRecords!=null&&smallRecords.size()!=0){
                  resultInfo.setSuccess(true);
                  resultInfo.setData(smallRecords);
              }else {
                  resultInfo.setSuccess(false);
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              om.writeValue(response.getWriter(),resultInfo);
          }

      }

      /**删除小组记录*/
      public void deSmallRecord(HttpServletRequest request,HttpServletResponse response) throws IOException {
          /**获取记录id*/
          String rid = request.getParameter("rid");
          SmallRecordDao srd = new SmallRecordDaoImp();
          boolean b = srd.deSR(Integer.parseInt(rid));
          /**设置回显信息*/
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          if(b){
              resultInfo.setSuccess(true);
              resultInfo.setMessage("删除成功");
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("删除失败");
          }
          om.writeValue(response.getWriter(),resultInfo);
      }

      /**完成任务*/
      public void completeTask(HttpServletRequest request,HttpServletResponse response) throws IOException {
          /**获取小组id和操作人number*/
          String gid = request.getParameter("gid");
          HttpSession session = request.getSession();
          Worker worker = (Worker) session.getAttribute("worker");
          String donumber = worker.getNumber();
          /**调用service方法*/
          SmallGroupService sgs=new SmallGroupServiceImp();
          /**设置回显信息*/
          response.setContentType("application/json;charset=utf-8");
          ResultInfo resultInfo = new ResultInfo();
          ObjectMapper om = new ObjectMapper();
          /**若没选组给提示*/
          if(gid!=""){
              boolean b = sgs.completeT(Integer.parseInt(gid), donumber);
              if(b){
                  resultInfo.setSuccess(true);
                  resultInfo.setMessage("提交成功");
              }else {
                  resultInfo.setSuccess(false);
                  resultInfo.setMessage("提交失败");
              }
              om.writeValue(response.getWriter(),resultInfo);
          }else {
              resultInfo.setSuccess(false);
              resultInfo.setMessage("请选择小组");
              om.writeValue(response.getWriter(),resultInfo);
          }


      }

}
